CREATE DATABASE student_records;

USE student_records;

CREATE TABLE students (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(30) NOT NULL,
    last_name VARCHAR(30) NOT NULL,
    grade VARCHAR(5) NOT NULL,
    email VARCHAR(50)
);
