<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $grade = $_POST['grade'];
    $email = $_POST['email'];

    $sql = "INSERT INTO students (first_name, last_name, grade, email) VALUES ('$firstName', '$lastName', '$grade', '$email')";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}
?>
