<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Student Records</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#">Student Portal</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Add Record</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view.php">View Records</a>
                    </li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="container">
        <h2 class="mt-5">Student Records</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Grade</th>
                    <th>Email</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'php/config.php';

                $result = mysqli_query($conn, "SELECT * FROM students");

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['first_name']}</td>
                            <td>{$row['last_name']}</td>
                            <td>{$row['grade']}</td>
                            <td>{$row['email']}</td>
                          </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <footer class="footer bg-light text-center text-lg-start">
        <div class="container p-4">
            <p>© 2024 Student Portal</p>
        </div>
    </footer>
</body>
</html>
